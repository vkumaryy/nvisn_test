from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import Fibonacci
import json

def create_fibonacci(n):
    if n <= 1:
        return n
    else:
        return create_fibonacci(n-1) + create_fibonacci(n-2)

@csrf_exempt
def fibonacci(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        n = int(data['n'])
        try:
            fib = Fibonacci.objects.get(n=n)
            result = fib.result
            status = "success"
        except Fibonacci.DoesNotExist:
            result = str(create_fibonacci(n))
            fib = Fibonacci(n=n, result=result)
            fib.save()
            status = "pending"
        return JsonResponse({"nth": result, "status": status})
    else:
        return JsonResponse({"message": "Method not allowed"}, status=405)
