from django.db import models

class Fibonacci(models.Model):
    n = models.IntegerField(unique=True)
    result = models.CharField(max_length=200)
